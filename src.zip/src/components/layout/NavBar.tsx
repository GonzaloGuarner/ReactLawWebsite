// src/components/layout/NavBar.tsx
import React from 'react';
import { Menu, X } from 'lucide-react';
import type { NavBarProps } from '../../types/types';
import logo from '../../assets/images/food-message-icon.png';



const NavBar: React.FC<NavBarProps> = ({ isScrolled, isMenuOpen, setIsMenuOpen, navigation, scrollToSection }) => {
  return (
    <nav className={`fixed top-0 w-full z-50 transition-all duration-300 bg-white ${isScrolled ? 'backdrop-blur-md bg-white/90 shadow-md py-2' : 'py-4'}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
  <img
    src={logo}
    alt="Food Message Logo"
    className={`h-12 w-12 transition-transform duration-300 ${isScrolled ? 'scale-90' : 'scale-100'}`}
  />
  <span
    className={`font-serif font-bold transition-all duration-300 ${isScrolled ? 'text-base' : 'text-lg'} text-primary`}
  >
    FOOD MESSAGE
  </span>
          

          <div className="hidden md:flex space-x-8">
            {navigation.map((item) => (
              <div key={item.name} className="relative group">
                <button
                  onClick={() => scrollToSection(item.href)}
                  className="text-black hover:text-primary hover:bg-primary_transparent px-3 py-2 text-sm font-serif font-semibold transition-colors"
                >
                  {item.name}
                </button>

                {item.subLinks && (
                  <div className="absolute font-serif font-semibold left-0 top-full mt-0 hidden group-hover:block bg-white shadow-md rounded-md z-50">
                    {item.subLinks.map((sub) => (
                      <a
                        key={sub.name}
                        href={sub.href}
                        className="block px-3 py-2 text-gray-700 hover:text-primary hover:bg-primary_transparent text-sm"
                      >
                        {sub.name}
                      </a>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>

          <button className="md:hidden p-2" onClick={() => setIsMenuOpen(!isMenuOpen)}>
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
        {isMenuOpen && (
          <div className="md:hidden bg-gray-100 py-4">
            {navigation.map((item) => (
              <div key={item.name}>
                <button
                  onClick={() => {

                    scrollToSection(item.href);
                    setIsMenuOpen(false);

                  }}
                  className="block w-full text-left px-4 py-2 text-gray-800 hover:bg-primary_focus"
                >
                  {item.name}
                </button>
                {item.subLinks && (
                  <div className="ml-4 border-l border-gray-300">
                    {item.subLinks.map((sub) => (
                      <a
                        key={sub.name}
                        href={sub.href}
                        className="block px-4 py-2 text-gray-700 hover:bg-primary_transparent text-sm"
                      >
                        {sub.name}
                      </a>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </nav>
  );
};

export default NavBar;
